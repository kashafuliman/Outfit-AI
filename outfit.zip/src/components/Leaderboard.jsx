import React from 'react';
import { motion } from 'framer-motion';
import { Trophy, Medal, Crown } from 'lucide-react';

const Leaderboard = () => {
    const leaders = [
        {
            rank: 2,
            name: "@Taha",
            score: 91,
            img: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=150&h=150&fit=crop",
            badge: <Medal className="text-gray-400" fill="currentColor" size={24} />
        },
        {
            rank: 1,
            name: "@Kashaf",
            score: 94,
            img: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150&h=150&fit=crop",
            badge: <Trophy className="text-yellow-400" fill="currentColor" size={32} />
        },
        {
            rank: 3,
            name: "@Fatima",
            score: 89,
            img: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=150&h=150&fit=crop",
            badge: <Medal className="text-amber-700" fill="currentColor" size={24} />
        }
    ];

    return (
        <section className="py-20 overflow-hidden">
            <div className="container text-center">
                <div className="mb-12">
                    <span className="bg-orange-500 text-white px-4 py-1 rounded-full text-xs font-medium uppercase tracking-wide mb-4 inline-block shadow-lg shadow-orange-500/30">
                        This Week's Leaders
                    </span>
                    <h2 className="text-4xl font-normal mb-3">Top Creators</h2>
                    <p className="text-gray-500">Join the competition and claim your spot</p>
                </div>

                <div className="flex flex-col md:flex-row items-end justify-center gap-6 md:gap-8 pb-10">
                    {leaders.map((leader) => (
                        <motion.div
                            key={leader.name}
                            initial={{ opacity: 0, y: 50 }}
                            whileInView={{ opacity: 1, y: 0 }}
                            viewport={{ once: true }}
                            className={`relative bg-white rounded-3xl p-6 shadow-xl flex flex-col items-center ${leader.rank === 1
                                ? 'w-full md:w-80 order-1 md:order-2 border-2 border-yellow-400 shadow-yellow-200 z-10 -mt-10 mb-10 md:mb-12 py-10 bg-gradient-to-b from-yellow-50 to-white'
                                : 'w-full md:w-64 order-2 md:order-1 border border-gray-100'
                                }`}
                        >
                            <div className="relative">
                                <div className={`absolute -top-4 -right-2 bg-white rounded-full p-1 shadow-md z-10`}>
                                    {leader.badge}
                                </div>
                                <img
                                    src={leader.img}
                                    alt={leader.name}
                                    className={`rounded-full object-cover border-4 ${leader.rank === 1 ? 'w-32 h-32 border-yellow-300' : 'w-24 h-24 border-gray-100'
                                        }`}
                                />
                                <div className={`absolute -bottom-3 left-1/2 -translate-x-1/2 w-8 h-8 rounded-full flex items-center justify-center text-white font-bold text-sm ${leader.rank === 1 ? 'bg-yellow-400' :
                                    leader.rank === 2 ? 'bg-gray-400' : 'bg-amber-700'
                                    }`}>
                                    #{leader.rank}
                                </div>
                            </div>

                            <h3 className="text-xl font-bold mt-8 mb-2 text-gray-800">{leader.name}</h3>

                            <div className="flex items-center gap-2">
                                <Crown size={18} className={leader.rank === 1 ? 'text-yellow-500' : 'text-gray-400'} fill={leader.rank === 1 ? 'currentColor' : 'none'} />
                                <span className={`text-2xl font-bold ${leader.rank === 1 ? 'text-pink-600' : 'text-purple-600'
                                    }`}>{leader.score}</span>
                            </div>

                            <span className="text-xs text-gray-400 mt-1 uppercase tracking-wide">Power Score</span>
                        </motion.div>
                    ))}
                </div>
            </div>
        </section>
    );
};

export default Leaderboard;
