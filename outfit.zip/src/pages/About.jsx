import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { 
    Sparkles, 
    Upload, 
    Bot, 
    Trophy, 
    Camera, 
    Target, 
    Palette, 
    TrendingUp, 
    Star,
    Brain,
    Users,
    Medal,
    Zap,
    ArrowRight,
    Play,
    CheckCircle,
    Flame
} from 'lucide-react';

const About = () => {
    const [currentStep, setCurrentStep] = useState(0);
    const [isPlaying, setIsPlaying] = useState(false);
    const [isPaused, setIsPaused] = useState(false);

    const steps = [
        {
            number: '01',
            icon: <Camera size={32} />,
            title: 'Upload Your Outfit',
            description: 'Take or upload a photo of your outfit. Our AI works with any angle or lighting.',
            color: 'from-pink-500 to-rose-500',
            bgColor: 'bg-pink-50',
            numberColor: 'text-pink-300'
        },
        {
            number: '02',
            icon: <Bot size={32} />,
            title: 'AI Analysis',
            description: 'Our advanced AI evaluates confidence, color balance, trends, and uniqueness in seconds.',
            color: 'from-purple-500 to-indigo-500',
            bgColor: 'bg-purple-50',
            numberColor: 'text-purple-300'
        },
        {
            number: '03',
            icon: <Trophy size={32} />,
            title: 'Get Your Score',
            description: 'Receive detailed feedback and compete on the leaderboard with fashion lovers worldwide.',
            color: 'from-teal-400 to-emerald-500',
            bgColor: 'bg-teal-50',
            numberColor: 'text-teal-300'
        }
    ];

    const dimensions = [
        {
            title: 'Confidence Level',
            description: 'AI analyzes your body language, posture, stance, and how you carry the outfit.',
            icon: <Target size={24} />,
            iconBg: 'from-pink-500 to-rose-500',
            bgColor: 'bg-purple-50',
            points: [
                'Posture analysis',
                'Body language detection',
                'Stance confidence',
                'Overall presence'
            ]
        },
        {
            title: 'Color Balance',
            description: 'Evaluates color theory, harmony, contrast, and professional coordination.',
            icon: <Palette size={24} />,
            iconBg: 'from-purple-500 to-indigo-500',
            bgColor: 'bg-purple-50',
            points: [
                'Hue harmony',
                'Contrast balance',
                'Color temperature',
                'Professional coordination'
            ]
        },
        {
            title: 'Trend Alignment',
            description: 'Measures alignment with current fashion trends, viral styles, and seasonal looks.',
            icon: <TrendingUp size={24} />,
            iconBg: 'from-teal-400 to-emerald-500',
            bgColor: 'bg-green-50',
            points: [
                'Current trends',
                'Viral TikTok styles',
                'Seasonal colors',
                'Challenge participation'
            ]
        },
        {
            title: 'Uniqueness',
            description: 'Rewards creativity, rare combinations, and experimental fashion choices.',
            icon: <Star size={24} />,
            iconBg: 'from-fuchsia-500 to-purple-600',
            bgColor: 'bg-purple-50',
            points: [
                'Creative layering',
                'Rare combinations',
                'Custom pieces',
                'Original expression'
            ]
        }
    ];

    const whyJoin = [
        {
            icon: <Brain size={32} />,
            title: 'Learn & Grow',
            description: 'Get AI-powered insights to improve your style',
            color: 'from-pink-500 to-rose-500'
        },
        {
            icon: <Users size={32} />,
            title: 'Community',
            description: 'Connect with fashion enthusiasts worldwide',
            color: 'from-purple-500 to-indigo-500'
        },
        {
            icon: <Medal size={32} />,
            title: 'Compete',
            description: 'Weekly competitions with exclusive rewards',
            color: 'from-teal-400 to-emerald-500'
        },
        {
            icon: <Zap size={32} />,
            title: 'Real-Time',
            description: 'Instant feedback and live score updates',
            color: 'from-orange-400 to-amber-500'
        }
    ];

    const features = [
        {
            icon: <Camera size={20} />,
            title: 'Screen Recording',
            description: 'Real app usage',
            color: 'text-purple-600'
        },
        {
            icon: <Users size={20} />,
            title: 'Voice Guide',
            description: 'Step explanations',
            color: 'text-purple-600'
        },
        {
            icon: <Sparkles size={20} />,
            title: 'Live Demo',
            description: 'Actual analysis',
            color: 'text-yellow-500'
        },
        {
            icon: <Brain size={20} />,
            title: 'Pro Tips',
            description: 'Expert advice',
            color: 'text-yellow-500'
        }
    ];

    const demoSteps = [
        {
            title: 'Step 1: Upload Your Outfit',
            content: (
                <div className="w-full h-full flex flex-col items-center justify-center p-8">
                    <div className="w-full max-w-md border-2 border-dashed border-purple-300 rounded-3xl p-12 bg-purple-50/50 flex flex-col items-center justify-center mb-6">
                        <Upload size={48} className="text-purple-500 mb-4" />
                        <h3 className="text-xl font-semibold text-gray-800 mb-2">Upload Your Outfit Photo</h3>
                        <p className="text-gray-600 text-center">Drag and drop or click to select</p>
                    </div>
                    <div className="flex items-center gap-2 text-purple-600">
                        <Camera size={20} />
                        <span className="text-sm font-medium">Selecting image...</span>
                    </div>
                </div>
            )
        },
        {
            title: 'Step 2: Select Context',
            content: (
                <div className="w-full h-full flex flex-col items-center justify-center p-8">
                    <div className="w-full max-w-md bg-white rounded-3xl p-8 border border-purple-100 shadow-lg">
                        <h3 className="text-xl font-semibold text-gray-800 mb-6">Select Context</h3>
                        <div className="space-y-3">
                            {['Casual', 'Office', 'Party', 'College', 'Wedding'].map((ctx, i) => (
                                <div
                                    key={i}
                                    className={`p-4 rounded-2xl border-2 flex items-center gap-4 ${
                                        ctx === 'Party' 
                                            ? 'border-purple-500 bg-purple-50' 
                                            : 'border-gray-100 bg-white'
                                    }`}
                                >
                                    <div className={`w-12 h-12 rounded-xl ${
                                        ctx === 'Party' ? 'bg-pink-500' : 'bg-gray-200'
                                    } flex items-center justify-center text-white`}>
                                        {ctx === 'Party' && <Sparkles size={24} />}
                                    </div>
                                    <span className="text-lg font-medium text-gray-700 flex-1">{ctx}</span>
                                    {ctx === 'Party' && (
                                        <div className="w-6 h-6 rounded-full bg-purple-500 flex items-center justify-center text-white">
                                            <CheckCircle size={16} />
                                        </div>
                                    )}
                                </div>
                            ))}
                        </div>
                    </div>
                    <div className="mt-4 flex items-center gap-2 text-purple-600">
                        <CheckCircle size={20} />
                        <span className="text-sm font-medium">Context selected: Party</span>
                    </div>
                </div>
            )
        },
        {
            title: 'Step 3: AI Analysis in Progress',
            content: (
                <div className="w-full h-full flex flex-col items-center justify-center p-8 bg-gradient-to-br from-purple-50 to-pink-50">
                    <div className="relative w-64 h-64 mb-8">
                        <div className="absolute inset-0 border-4 border-purple-500 border-t-transparent rounded-full animate-spin"></div>
                        <div className="absolute inset-4 border-4 border-pink-500 border-t-transparent rounded-full animate-spin" style={{ animationDirection: 'reverse', animationDuration: '1.5s' }}></div>
                        <div className="absolute inset-0 flex items-center justify-center">
                            <Bot size={64} className="text-purple-600 animate-pulse" />
                        </div>
                    </div>
                    <h3 className="text-2xl font-semibold text-gray-800 mb-2">AI Analyzing Your Outfit...</h3>
                    <div className="space-y-2 mt-4">
                        <div className="flex items-center gap-2 text-sm text-gray-600">
                            <div className="w-2 h-2 rounded-full bg-green-500 animate-pulse"></div>
                            <span>Analyzing posture and body language</span>
                        </div>
                        <div className="flex items-center gap-2 text-sm text-gray-600">
                            <div className="w-2 h-2 rounded-full bg-green-500 animate-pulse"></div>
                            <span>Evaluating color balance and harmony</span>
                        </div>
                        <div className="flex items-center gap-2 text-sm text-gray-600">
                            <div className="w-2 h-2 rounded-full bg-yellow-500 animate-pulse"></div>
                            <span>Checking trend alignment...</span>
                        </div>
                        <div className="flex items-center gap-2 text-sm text-gray-600">
                            <div className="w-2 h-2 rounded-full bg-gray-300"></div>
                            <span>Calculating uniqueness score</span>
                        </div>
                    </div>
                </div>
            )
        },
        {
            title: 'Step 4: Your Power Score Results',
            content: (
                <div className="w-full h-full flex flex-col items-center justify-center p-8 bg-gradient-to-br from-pink-50 to-purple-50">
                    <div className="w-full max-w-2xl space-y-4">
                        <div className="bg-white rounded-3xl p-6 border border-pink-100 shadow-lg">
                            <div className="flex items-center justify-between mb-4">
                                <h3 className="text-xl font-semibold text-gray-800">Confidence Score</h3>
                                <div className="text-center">
                                    <span className="text-4xl font-bold text-pink-600">78</span>
                                    <span className="text-sm text-gray-500 block">/ 100</span>
                                </div>
                            </div>
                            <div className="space-y-2">
                                <div className="flex items-center gap-2 text-sm">
                                    <CheckCircle size={16} className="text-green-500" />
                                    <span className="text-gray-700">Head Position: Perfectly aligned</span>
                                </div>
                                <div className="flex items-center gap-2 text-sm">
                                    <CheckCircle size={16} className="text-green-500" />
                                    <span className="text-gray-700">Back Posture: Straight and confident</span>
                                </div>
                            </div>
                        </div>
                        <div className="bg-white rounded-3xl p-6 border border-purple-100 shadow-lg">
                            <div className="flex items-center justify-between mb-4">
                                <h3 className="text-xl font-semibold text-gray-800">Outfit Suitability</h3>
                                <div className="text-center">
                                    <span className="text-4xl font-bold text-purple-600">85%</span>
                                    <span className="text-sm text-gray-500 block">Match</span>
                                </div>
                            </div>
                            <div className="space-y-2">
                                <div className="flex items-center gap-2 text-sm">
                                    <CheckCircle size={16} className="text-green-500" />
                                    <span className="text-gray-700">Colors are appropriate for party wear</span>
                                </div>
                                <div className="flex items-center gap-2 text-sm">
                                    <CheckCircle size={16} className="text-green-500" />
                                    <span className="text-gray-700">Overall style matches the context well</span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            )
        },
        {
            title: 'Step 5: Improvement Suggestions & Shopping',
            content: (
                <div className="w-full h-full flex flex-col items-center justify-center p-8 bg-gradient-to-br from-teal-50 to-purple-50">
                    <div className="w-full max-w-2xl space-y-4">
                        <div className="bg-white rounded-3xl p-6 border border-teal-100 shadow-lg">
                            <h3 className="text-xl font-semibold text-gray-800 mb-4 flex items-center gap-2">
                                <Sparkles size={24} className="text-teal-600" />
                                Improvement Suggestions
                            </h3>
                            <ul className="space-y-2">
                                <li className="flex items-start gap-2 text-sm text-gray-700">
                                    <CheckCircle size={18} className="text-teal-600 mt-0.5" />
                                    <span>Try a cropped jacket to balance proportions</span>
                                </li>
                                <li className="flex items-start gap-2 text-sm text-gray-700">
                                    <CheckCircle size={18} className="text-teal-600 mt-0.5" />
                                    <span>Replace black shoes with white sneakers for better contrast</span>
                                </li>
                                <li className="flex items-start gap-2 text-sm text-gray-700">
                                    <CheckCircle size={18} className="text-teal-600 mt-0.5" />
                                    <span>Add a statement belt to define waist and add structure</span>
                                </li>
                            </ul>
                        </div>
                        <div className="bg-white rounded-3xl p-6 border border-yellow-100 shadow-lg">
                            <h3 className="text-xl font-semibold text-gray-800 mb-4 flex items-center gap-2">
                                <Trophy size={24} className="text-yellow-600" />
                                Shop Similar Items
                            </h3>
                            <div className="grid grid-cols-2 gap-4">
                                <div className="p-4 bg-gray-50 rounded-xl border border-gray-100">
                                    <h4 className="font-semibold text-gray-800 text-sm mb-1">Slim Fit Blazer</h4>
                                    <p className="text-purple-600 text-xs font-bold mb-1">Zara</p>
                                    <p className="text-gray-500 text-xs">$89.90</p>
                                </div>
                                <div className="p-4 bg-gray-50 rounded-xl border border-gray-100">
                                    <h4 className="font-semibold text-gray-800 text-sm mb-1">White Sneakers</h4>
                                    <p className="text-purple-600 text-xs font-bold mb-1">Nike</p>
                                    <p className="text-gray-500 text-xs">$110.00</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            )
        }
    ];

    // Auto-play through demo steps
    useEffect(() => {
        if (isPlaying && !isPaused) {
            const timer = setTimeout(() => {
                if (currentStep < demoSteps.length - 1) {
                    setCurrentStep(currentStep + 1);
                } else {
                    setIsPlaying(false);
                    setCurrentStep(0);
                }
            }, 4000); // 4 seconds per step

            return () => clearTimeout(timer);
        }
    }, [isPlaying, isPaused, currentStep, demoSteps.length]);

    const handlePlay = () => {
        setIsPlaying(true);
        setIsPaused(false);
        setCurrentStep(0);
    };

    const handlePause = () => {
        setIsPaused(!isPaused);
    };

    const handleReset = () => {
        setIsPlaying(false);
        setIsPaused(false);
        setCurrentStep(0);
    };

    const handleNext = () => {
        if (currentStep < demoSteps.length - 1) {
            setCurrentStep(currentStep + 1);
        }
    };

    const handlePrev = () => {
        if (currentStep > 0) {
            setCurrentStep(currentStep - 1);
        }
    };

    return (
        <div className="min-h-screen">
            {/* Hero Section */}
            <section className="relative pt-32 pb-20 overflow-hidden">
                <motion.div 
                    className="absolute top-0 left-1/2 -translate-x-1/2 w-[1000px] h-[600px] bg-purple-200/30 rounded-full blur-[120px] -z-10 pointer-events-none"
                    animate={{ 
                        scale: [1, 1.2, 1],
                        opacity: [0.3, 0.5, 0.3]
                    }}
                    transition={{ 
                        duration: 8,
                        repeat: Infinity,
                        ease: "easeInOut"
                    }}
                />
                <motion.div 
                    className="absolute top-20 right-1/4 w-[600px] h-[400px] bg-pink-200/20 rounded-full blur-[100px] -z-10 pointer-events-none"
                    animate={{ 
                        scale: [1, 1.3, 1],
                        x: [0, 50, 0],
                        y: [0, -30, 0]
                    }}
                    transition={{ 
                        duration: 10,
                        repeat: Infinity,
                        ease: "easeInOut"
                    }}
                />
                
                <div className="container text-center">
                    <motion.div
                        initial={{ opacity: 0, y: 20, scale: 0.9 }}
                        animate={{ opacity: 1, y: 0, scale: 1 }}
                        transition={{ type: "spring", stiffness: 200, damping: 15 }}
                        className="inline-flex items-center gap-2 bg-gradient-to-r from-pink-500 to-purple-600 text-white px-6 py-3 rounded-full mb-8 shadow-lg"
                    >
                        <motion.div
                            animate={{ rotate: [0, 10, -10, 0] }}
                            transition={{ duration: 2, repeat: Infinity, repeatDelay: 1 }}
                        >
                            <Sparkles size={20} />
                        </motion.div>
                        <span className="font-medium">HOW IT WORKS</span>
                    </motion.div>

                    <motion.h1
                        initial={{ opacity: 0, y: 30 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ delay: 0.1, type: "spring", stiffness: 100 }}
                        className="text-5xl md:text-7xl font-normal mb-6"
                    >
                        <motion.span
                            initial={{ opacity: 0, x: -20 }}
                            animate={{ opacity: 1, x: 0 }}
                            transition={{ delay: 0.2 }}
                            className="text-pink-600 inline-block"
                        >
                            AI-Powered
                        </motion.span>{' '}
                        <motion.span
                            initial={{ opacity: 0, x: 20 }}
                            animate={{ opacity: 1, x: 0 }}
                            transition={{ delay: 0.3 }}
                            className="bg-gradient-to-r from-purple-600 via-indigo-600 to-teal-500 bg-clip-text text-transparent inline-block"
                        >
                            Fashion Intelligence
                        </motion.span>
                    </motion.h1>

                    <motion.p
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ delay: 0.2 }}
                        className="text-xl text-gray-600 max-w-3xl mx-auto mb-4"
                    >
                        Outfit Power Score uses advanced AI to analyze your fashion choices across four key dimensions, giving you instant feedback to level up your style game.
                    </motion.p>

                    <motion.p
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ delay: 0.3 }}
                        className="text-2xl font-medium text-gray-800 mt-8"
                    >
                        Get Your Power Score in 3 Steps
                    </motion.p>
                </div>
            </section>

            {/* 3 Steps Section */}
            <section className="py-20 bg-gradient-to-b from-white to-purple-50/30 relative overflow-hidden">
                <motion.div
                    className="absolute top-1/4 left-0 w-96 h-96 bg-purple-100/20 rounded-full blur-3xl -z-10"
                    animate={{
                        x: [0, 100, 0],
                        y: [0, 50, 0],
                        scale: [1, 1.2, 1]
                    }}
                    transition={{
                        duration: 15,
                        repeat: Infinity,
                        ease: "easeInOut"
                    }}
                />
                <motion.div
                    className="absolute bottom-1/4 right-0 w-96 h-96 bg-pink-100/20 rounded-full blur-3xl -z-10"
                    animate={{
                        x: [0, -100, 0],
                        y: [0, -50, 0],
                        scale: [1, 1.2, 1]
                    }}
                    transition={{
                        duration: 12,
                        repeat: Infinity,
                        ease: "easeInOut"
                    }}
                />
                <div className="container">
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-6xl mx-auto">
                        {steps.map((step, index) => (
                            <motion.div
                                key={index}
                                initial={{ opacity: 0, y: 50, scale: 0.9 }}
                                whileInView={{ opacity: 1, y: 0, scale: 1 }}
                                viewport={{ once: true, margin: "-100px" }}
                                transition={{ 
                                    delay: index * 0.15,
                                    type: "spring",
                                    stiffness: 100,
                                    damping: 15
                                }}
                                whileHover={{ y: -10, scale: 1.02 }}
                                className="relative"
                            >
                                <motion.div 
                                    className={`${step.bgColor} rounded-3xl p-8 h-full border border-white/50 shadow-lg hover:shadow-2xl transition-all`}
                                    whileHover={{ boxShadow: "0 20px 40px rgba(0,0,0,0.1)" }}
                                >
                                    <div className="flex items-start gap-4 mb-6">
                                        <motion.div 
                                            className={`w-16 h-16 rounded-2xl bg-gradient-to-br ${step.color} flex items-center justify-center text-white shadow-lg flex-shrink-0`}
                                            whileHover={{ 
                                                rotate: [0, -10, 10, -10, 0],
                                                scale: 1.1
                                            }}
                                            transition={{ duration: 0.5 }}
                                        >
                                            {step.icon}
                                        </motion.div>
                                        <div className="flex-1">
                                            <motion.div 
                                                className={`text-6xl font-bold ${step.numberColor} mb-2`}
                                                initial={{ scale: 0 }}
                                                whileInView={{ scale: 1 }}
                                                viewport={{ once: true }}
                                                transition={{ 
                                                    delay: index * 0.15 + 0.2,
                                                    type: "spring",
                                                    stiffness: 200
                                                }}
                                            >
                                                {step.number}
                                            </motion.div>
                                        </div>
                                    </div>
                                    <h3 className="text-2xl font-semibold text-gray-800 mb-3">
                                        {step.title}
                                    </h3>
                                    <p className="text-gray-600 leading-relaxed">
                                        {step.description}
                                    </p>
                                </motion.div>
                                {index < steps.length - 1 && (
                                    <motion.div 
                                        className="hidden md:block absolute top-1/2 -right-4 w-8 h-0.5 bg-gradient-to-r from-purple-300 to-purple-100 z-10"
                                        initial={{ scaleX: 0 }}
                                        whileInView={{ scaleX: 1 }}
                                        viewport={{ once: true }}
                                        transition={{ delay: index * 0.15 + 0.5, duration: 0.5 }}
                                    ></motion.div>
                                )}
                            </motion.div>
                        ))}
                    </div>
                </div>
            </section>

            {/* Demo Video Section */}
            <section className="py-20">
                <div className="container">
                    <div className="text-center mb-12">
                        <motion.div
                            initial={{ opacity: 0, scale: 0, rotate: -180 }}
                            whileInView={{ opacity: 1, scale: 1, rotate: 0 }}
                            viewport={{ once: true }}
                            transition={{ type: "spring", stiffness: 200 }}
                            className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-purple-100 mb-6"
                        >
                            <motion.div
                                animate={{ 
                                    rotate: [0, 360],
                                    scale: [1, 1.2, 1]
                                }}
                                transition={{ 
                                    duration: 3,
                                    repeat: Infinity,
                                    repeatDelay: 2
                                }}
                            >
                                <Sparkles size={32} className="text-purple-600" />
                            </motion.div>
                        </motion.div>
                        <motion.h2
                            initial={{ opacity: 0, y: 20 }}
                            whileInView={{ opacity: 1, y: 0 }}
                            viewport={{ once: true }}
                            transition={{ delay: 0.2 }}
                            className="text-4xl md:text-5xl font-normal text-gray-800 mb-4"
                        >
                            Watch How It Works
                        </motion.h2>
                        <motion.p
                            initial={{ opacity: 0, y: 20 }}
                            whileInView={{ opacity: 1, y: 0 }}
                            viewport={{ once: true }}
                            transition={{ delay: 0.3 }}
                            className="text-xl text-gray-600 max-w-2xl mx-auto"
                        >
                            See the complete workflow in action - from upload to detailed analysis
                        </motion.p>
                    </div>

                    <motion.div
                        initial={{ opacity: 0, y: 50, scale: 0.95 }}
                        whileInView={{ opacity: 1, y: 0, scale: 1 }}
                        viewport={{ once: true, margin: "-50px" }}
                        transition={{ type: "spring", stiffness: 100, damping: 15 }}
                        whileHover={{ scale: 1.01 }}
                        className="max-w-5xl mx-auto"
                    >
                        <motion.div 
                            className="bg-gray-900 rounded-3xl overflow-hidden shadow-2xl border-8 border-gray-800"
                            initial={{ boxShadow: "0 20px 60px rgba(0,0,0,0.3)" }}
                            whileInView={{ boxShadow: "0 30px 80px rgba(168,85,247,0.4)" }}
                            viewport={{ once: true }}
                            transition={{ duration: 0.5 }}
                        >
                            {/* Browser Frame */}
                            <div className="bg-gray-800 px-4 py-3 flex items-center gap-2">
                                <div className="flex gap-2">
                                    <div className="w-3 h-3 rounded-full bg-red-500"></div>
                                    <div className="w-3 h-3 rounded-full bg-yellow-500"></div>
                                    <div className="w-3 h-3 rounded-full bg-green-500"></div>
                                </div>
                                <div className="flex-1 bg-gray-700 rounded-lg px-4 py-1.5 text-gray-400 text-sm text-center max-w-md mx-auto">
                                    outfitpowerscore.com/upload
                                </div>
                            </div>

                            {/* Interactive Demo Player */}
                            <div className="relative aspect-video bg-gradient-to-br from-gray-50 to-white overflow-hidden">
                                {!isPlaying && currentStep === 0 ? (
                                    <div className="absolute inset-0 flex flex-col items-center justify-center bg-gradient-to-r from-pink-500 via-purple-500 to-indigo-500">
                                        <div className="text-center text-white mb-8">
                                            <h3 className="text-3xl font-bold mb-2">Interactive Demo</h3>
                                            <p className="text-white/90">Watch how Outfit Power Score works</p>
                                        </div>
                                        <motion.button
                                            onClick={handlePlay}
                                            whileHover={{ scale: 1.15, rotate: 5 }}
                                            whileTap={{ scale: 0.95 }}
                                            animate={{ 
                                                boxShadow: [
                                                    "0 0 0 0 rgba(168, 85, 247, 0.7)",
                                                    "0 0 0 20px rgba(168, 85, 247, 0)",
                                                    "0 0 0 0 rgba(168, 85, 247, 0)"
                                                ]
                                            }}
                                            transition={{ 
                                                duration: 2,
                                                repeat: Infinity
                                            }}
                                            className="w-20 h-20 rounded-full bg-white/90 hover:bg-white transition-all flex items-center justify-center shadow-2xl"
                                        >
                                            <motion.div
                                                animate={{ scale: [1, 1.2, 1] }}
                                                transition={{ duration: 1.5, repeat: Infinity }}
                                            >
                                                <Play size={32} className="text-purple-600 ml-1" fill="currentColor" />
                                            </motion.div>
                                        </motion.button>
                                        <div className="absolute bottom-4 left-4 text-white/70 text-xs">
                                            <div className="flex items-center gap-2">
                                                <Camera size={16} />
                                                <span>Screen Recording</span>
                                            </div>
                                        </div>
                                    </div>
                                ) : (
                                    <>
                                        {/* Demo Content */}
                                        <motion.div
                                            key={currentStep}
                                            initial={{ opacity: 0, x: 50, scale: 0.95 }}
                                            animate={{ opacity: 1, x: 0, scale: 1 }}
                                            exit={{ opacity: 0, x: -50, scale: 0.95 }}
                                            transition={{ 
                                                type: "spring",
                                                stiffness: 100,
                                                damping: 15
                                            }}
                                            className="absolute inset-0"
                                        >
                                            {demoSteps[currentStep].content}
                                        </motion.div>

                                        {/* Step Indicator */}
                                        <motion.div 
                                            key={currentStep}
                                            initial={{ opacity: 0, scale: 0.8 }}
                                            animate={{ opacity: 1, scale: 1 }}
                                            transition={{ type: "spring", stiffness: 200 }}
                                            className="absolute top-4 left-4 bg-black/70 backdrop-blur-sm text-white px-4 py-2 rounded-full text-sm font-medium"
                                        >
                                            {currentStep + 1} / {demoSteps.length} - {demoSteps[currentStep].title}
                                        </motion.div>

                                        {/* Progress Bar */}
                                        {isPlaying && (
                                            <div className="absolute top-0 left-0 right-0 h-1 bg-gray-200">
                                                <motion.div
                                                    className="h-full bg-gradient-to-r from-pink-500 to-purple-500"
                                                    initial={{ width: '0%' }}
                                                    animate={{ 
                                                        width: isPaused ? 'auto' : '100%',
                                                    }}
                                                    transition={{ 
                                                        duration: 4,
                                                        ease: 'linear'
                                                    }}
                                                />
                                            </div>
                                        )}

                                        {/* Controls */}
                                        <div className="absolute bottom-4 left-1/2 -translate-x-1/2 flex items-center gap-3 bg-black/70 backdrop-blur-sm px-6 py-3 rounded-full">
                                            <button
                                                onClick={handlePrev}
                                                disabled={currentStep === 0}
                                                className="text-white hover:text-purple-300 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
                                            >
                                                <ArrowRight size={20} className="rotate-180" />
                                            </button>
                                            
                                            {isPlaying ? (
                                                <button
                                                    onClick={handlePause}
                                                    className="w-12 h-12 rounded-full bg-white/90 hover:bg-white transition-all flex items-center justify-center"
                                                >
                                                    {isPaused ? (
                                                        <Play size={20} className="text-purple-600 ml-0.5" fill="currentColor" />
                                                    ) : (
                                                        <div className="flex gap-1">
                                                            <div className="w-1 h-4 bg-purple-600"></div>
                                                            <div className="w-1 h-4 bg-purple-600"></div>
                                                        </div>
                                                    )}
                                                </button>
                                            ) : (
                                                <button
                                                    onClick={handlePlay}
                                                    className="w-12 h-12 rounded-full bg-white/90 hover:bg-white transition-all flex items-center justify-center"
                                                >
                                                    <Play size={20} className="text-purple-600 ml-0.5" fill="currentColor" />
                                                </button>
                                            )}

                                            <button
                                                onClick={handleNext}
                                                disabled={currentStep === demoSteps.length - 1}
                                                className="text-white hover:text-purple-300 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
                                            >
                                                <ArrowRight size={20} />
                                            </button>

                                            <button
                                                onClick={handleReset}
                                                className="ml-4 text-white/70 hover:text-white text-xs px-3 py-1.5 rounded-lg bg-white/10 hover:bg-white/20 transition-colors"
                                            >
                                                Reset
                                            </button>
                                        </div>
                                    </>
                                )}
                            </div>
                        </motion.div>

                    {/* Video Features */}
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mt-12 max-w-4xl mx-auto">
                        {features.map((feature, index) => (
                            <motion.div
                                key={index}
                                initial={{ opacity: 0, y: 30, scale: 0.9 }}
                                whileInView={{ opacity: 1, y: 0, scale: 1 }}
                                viewport={{ once: true, margin: "-50px" }}
                                transition={{ 
                                    delay: index * 0.1,
                                    type: "spring",
                                    stiffness: 150
                                }}
                                whileHover={{ 
                                    y: -8,
                                    scale: 1.05,
                                    rotate: [0, -2, 2, 0]
                                }}
                                className="bg-white rounded-2xl p-6 text-center border border-gray-100 shadow-sm hover:shadow-xl transition-all cursor-pointer"
                            >
                                <motion.div 
                                    className={`${feature.color} mb-3 flex justify-center`}
                                    whileHover={{ 
                                        scale: 1.2,
                                        rotate: 360
                                    }}
                                    transition={{ duration: 0.5 }}
                                >
                                    {feature.icon}
                                </motion.div>
                                <h4 className="font-semibold text-gray-800 mb-1">{feature.title}</h4>
                                <p className="text-sm text-gray-500">{feature.description}</p>
                            </motion.div>
                        ))}
                    </div>
                    </motion.div>
                </div>
            </section>

            {/* Four Dimensions Section */}
            <section className="py-20 bg-gradient-to-b from-purple-50/30 to-white">
                <div className="container">
                    <div className="text-center mb-16">
                        <motion.h2
                            initial={{ opacity: 0, y: 30 }}
                            whileInView={{ opacity: 1, y: 0 }}
                            viewport={{ once: true }}
                            transition={{ type: "spring", stiffness: 100 }}
                            className="text-4xl md:text-5xl font-normal text-gray-800 mb-4"
                        >
                            Four Dimensions of Style
                        </motion.h2>
                        <motion.p
                            initial={{ opacity: 0, y: 20 }}
                            whileInView={{ opacity: 1, y: 0 }}
                            viewport={{ once: true }}
                            transition={{ delay: 0.2 }}
                            className="text-xl text-gray-600 max-w-3xl mx-auto"
                        >
                            Our AI analyzes your outfit across these critical fashion metrics to give you a comprehensive Power Score
                        </motion.p>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-6xl mx-auto">
                        {dimensions.map((dimension, index) => (
                            <motion.div
                                key={index}
                                initial={{ opacity: 0, y: 50, scale: 0.95 }}
                                whileInView={{ opacity: 1, y: 0, scale: 1 }}
                                viewport={{ once: true, margin: "-100px" }}
                                transition={{ 
                                    delay: index * 0.15,
                                    type: "spring",
                                    stiffness: 100,
                                    damping: 15
                                }}
                                whileHover={{ 
                                    y: -10,
                                    scale: 1.02,
                                    boxShadow: "0 25px 50px rgba(0,0,0,0.15)"
                                }}
                                className={`${dimension.bgColor} rounded-3xl p-8 border border-white/50 shadow-lg hover:shadow-2xl transition-all`}
                            >
                                <div className="flex items-start gap-4 mb-4">
                                    <motion.div 
                                        className={`w-14 h-14 rounded-2xl bg-gradient-to-br ${dimension.iconBg} flex items-center justify-center text-white shadow-md flex-shrink-0`}
                                        whileHover={{ 
                                            rotate: [0, -15, 15, -15, 0],
                                            scale: 1.15
                                        }}
                                        transition={{ duration: 0.6 }}
                                    >
                                        {dimension.icon}
                                    </motion.div>
                                    <div className="flex-1">
                                        <h3 className="text-2xl font-semibold text-gray-800 mb-2">
                                            {dimension.title}
                                        </h3>
                                        <p className="text-gray-600 mb-4">
                                            {dimension.description}
                                        </p>
                                    </div>
                                </div>
                                <motion.ul 
                                    className="space-y-2"
                                    initial="hidden"
                                    whileInView="visible"
                                    viewport={{ once: true }}
                                    variants={{
                                        visible: {
                                            transition: {
                                                staggerChildren: 0.1
                                            }
                                        }
                                    }}
                                >
                                    {dimension.points.map((point, i) => (
                                        <motion.li 
                                            key={i} 
                                            className="flex items-center gap-2 text-gray-700"
                                            variants={{
                                                hidden: { opacity: 0, x: -20 },
                                                visible: { 
                                                    opacity: 1, 
                                                    x: 0,
                                                    transition: {
                                                        type: "spring",
                                                        stiffness: 100
                                                    }
                                                }
                                            }}
                                            whileHover={{ x: 5 }}
                                        >
                                            <motion.div 
                                                className={`w-2 h-2 rounded-full bg-gradient-to-br ${dimension.iconBg}`}
                                                animate={{ 
                                                    scale: [1, 1.5, 1],
                                                    opacity: [0.7, 1, 0.7]
                                                }}
                                                transition={{ 
                                                    duration: 2,
                                                    repeat: Infinity,
                                                    delay: i * 0.3
                                                }}
                                            />
                                            <span>{point}</span>
                                        </motion.li>
                                    ))}
                                </motion.ul>
                            </motion.div>
                        ))}
                    </div>
                </div>
            </section>

            {/* Why Join Section */}
            <section className="py-20">
                <div className="container">
                    <div className="text-center mb-16">
                        <motion.h2
                            initial={{ opacity: 0, y: 30 }}
                            whileInView={{ opacity: 1, y: 0 }}
                            viewport={{ once: true }}
                            transition={{ type: "spring", stiffness: 100 }}
                            className="text-4xl md:text-5xl font-normal text-gray-800 mb-4"
                        >
                            Why Join Outfit Power Score?
                        </motion.h2>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 max-w-6xl mx-auto">
                        {whyJoin.map((item, index) => (
                            <motion.div
                                key={index}
                                initial={{ opacity: 0, scale: 0.8, rotateY: -90 }}
                                whileInView={{ opacity: 1, scale: 1, rotateY: 0 }}
                                viewport={{ once: true, margin: "-50px" }}
                                transition={{ 
                                    delay: index * 0.1,
                                    type: "spring",
                                    stiffness: 150
                                }}
                                whileHover={{ 
                                    y: -15,
                                    scale: 1.05,
                                    rotateY: 5,
                                    boxShadow: "0 20px 40px rgba(0,0,0,0.15)"
                                }}
                                className="bg-white rounded-3xl p-8 border border-gray-100 shadow-lg hover:shadow-2xl transition-all text-center"
                            >
                                <motion.div 
                                    className={`w-16 h-16 rounded-2xl bg-gradient-to-br ${item.color} flex items-center justify-center text-white shadow-lg mx-auto mb-6`}
                                    whileHover={{ 
                                        rotate: 360,
                                        scale: 1.2
                                    }}
                                    transition={{ duration: 0.6 }}
                                >
                                    {item.icon}
                                </motion.div>
                                <h3 className="text-xl font-semibold text-gray-800 mb-3">
                                    {item.title}
                                </h3>
                                <p className="text-gray-600 text-sm">
                                    {item.description}
                                </p>
                            </motion.div>
                        ))}
                    </div>
                </div>
            </section>

            {/* CTA Section */}
            <section className="py-20 pb-32">
                <div className="container px-4">
                        <motion.div
                            initial={{ opacity: 0, scale: 0.9, y: 50 }}
                            whileInView={{ opacity: 1, scale: 1, y: 0 }}
                            viewport={{ once: true, margin: "-100px" }}
                            transition={{ type: "spring", stiffness: 100, damping: 15 }}
                            whileHover={{ scale: 1.02 }}
                            className="relative rounded-[2.5rem] overflow-hidden bg-gradient-to-r from-[#DB00FF] via-[#7E22CE] to-[#00E5FF] shadow-2xl p-10 md:p-16 text-center mx-auto max-w-5xl"
                        >
                            <motion.div 
                                className="absolute top-10 right-10 text-white/20"
                                animate={{ 
                                    rotate: [0, 360],
                                    scale: [1, 1.2, 1]
                                }}
                                transition={{ 
                                    duration: 4,
                                    repeat: Infinity,
                                    repeatDelay: 1
                                }}
                            >
                                <Sparkles size={48} fill="currentColor" />
                            </motion.div>
                            <motion.div 
                                className="absolute bottom-10 left-10 text-white/20"
                                animate={{ 
                                    y: [0, -20, 0],
                                    rotate: [0, 10, -10, 0]
                                }}
                                transition={{ 
                                    duration: 3,
                                    repeat: Infinity
                                }}
                            >
                                <Star size={32} fill="currentColor" />
                            </motion.div>
                            <motion.div
                                animate={{ 
                                    rotate: 360,
                                    scale: [1, 1.1, 1]
                                }}
                                transition={{ 
                                    duration: 20,
                                    repeat: Infinity,
                                    ease: "linear"
                                }}
                                className="absolute -top-20 -left-20 w-64 h-64 bg-white/10 rounded-full blur-3xl"
                            />

                            <div className="relative z-10 flex flex-col items-center">
                                <motion.div
                                    initial={{ y: 20, opacity: 0 }}
                                    whileInView={{ y: 0, opacity: 1 }}
                                    viewport={{ once: true }}
                                    transition={{ delay: 0.2, type: "spring", stiffness: 100 }}
                                    className="mb-8"
                                >
                                    <motion.div
                                        animate={{ 
                                            rotate: [0, 10, -10, 0],
                                            scale: [1, 1.1, 1]
                                        }}
                                        transition={{ 
                                            duration: 2,
                                            repeat: Infinity
                                        }}
                                    >
                                        <Sparkles size={64} className="text-white mx-auto mb-6" />
                                    </motion.div>
                                    <motion.h2
                                        initial={{ opacity: 0, scale: 0.9 }}
                                        whileInView={{ opacity: 1, scale: 1 }}
                                        viewport={{ once: true }}
                                        transition={{ delay: 0.3 }}
                                        className="text-4xl md:text-5xl font-medium text-white mb-6"
                                    >
                                        Ready to Discover Your Power Score?
                                    </motion.h2>
                                    <motion.p
                                        initial={{ opacity: 0, y: 10 }}
                                        whileInView={{ opacity: 1, y: 0 }}
                                        viewport={{ once: true }}
                                        transition={{ delay: 0.4 }}
                                        className="text-purple-100 text-xl max-w-2xl mx-auto mb-10"
                                    >
                                        Join our community and start your journey to becoming a top-ranked fashion creator
                                    </motion.p>
                                </motion.div>

                                <motion.div
                                    whileHover={{ scale: 1.1 }}
                                    whileTap={{ scale: 0.95 }}
                                >
                                    <Link
                                        to="/analyze"
                                        className="bg-white text-purple-600 px-10 py-4 rounded-full font-bold text-lg shadow-lg hover:shadow-xl transition-all inline-flex items-center gap-2"
                                    >
                                        <motion.div
                                            animate={{ rotate: [0, 360] }}
                                            transition={{ 
                                                duration: 2,
                                                repeat: Infinity,
                                                ease: "linear"
                                            }}
                                        >
                                            <Sparkles size={20} />
                                        </motion.div>
                                        Get Started Free
                                        <motion.div
                                            animate={{ x: [0, 5, 0] }}
                                            transition={{ 
                                                duration: 1.5,
                                                repeat: Infinity
                                            }}
                                        >
                                            <ArrowRight size={20} />
                                        </motion.div>
                                    </Link>
                                </motion.div>
                            </div>
                    </motion.div>
                </div>
            </section>
        </div>
    );
};

export default About;

